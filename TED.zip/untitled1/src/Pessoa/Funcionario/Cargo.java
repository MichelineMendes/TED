package Pessoa.Funcionario;

public class Cargo {
}
