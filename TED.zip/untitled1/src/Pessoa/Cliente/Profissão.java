package Pessoa.Cliente;

public class Profissão {
}
