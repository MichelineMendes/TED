package Pessoa;

public class Endereco {
}
