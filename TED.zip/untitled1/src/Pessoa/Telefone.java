package Pessoa;

public class Telefone {
}
